#!/bin/bash
java -jar JavaMiniGame.jar